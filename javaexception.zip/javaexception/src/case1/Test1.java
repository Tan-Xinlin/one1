package case1;

public class Test1 {
    public static void main(String[] args) {
        int a = 0;
        int b = 2;
        int c = b / a;
        System.out.println(c);
    }
}
