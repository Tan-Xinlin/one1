package case1;

public class Test2 {

    public static void main(String[] args) {
        Test2.cal1();
    }

    public static void cal1(){
        Test2.cal2();
    }

    public static void cal2(){
        int[] a = new int[2];
        for (int i = 0; i <= 2; i++) {
            a[i] = i;
        }
    }
}
