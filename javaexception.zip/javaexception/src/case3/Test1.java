package case3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Test1 {
    public static void main(String[] args) {
        Test1.f();
    }

    public static void f(){
        //不try catch可以吗
        //FileInputStream fi = new FileInputStream("D://a.txt");
        try {
            FileInputStream fi = new FileInputStream("D://a.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
