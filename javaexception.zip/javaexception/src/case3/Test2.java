package case3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Test2 {

    public static void main(String[] args){
        try {
            Test2.f();
        } catch (FileNotFoundException e) {
            //catch (Exception e) { //替换上这句也可以
            e.printStackTrace();
        }
    }

    public static void f() throws FileNotFoundException{
        FileInputStream fi = new FileInputStream("D://a.txt");
    }

}
