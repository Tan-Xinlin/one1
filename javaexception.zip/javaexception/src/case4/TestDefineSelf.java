package case4;

public class TestDefineSelf {

    public static void main(String[] args) {
        int[] moneys = {1, 5, -2};
        //int[] moneys = {1, 5, 10};
        try {
            TestDefineSelf.totalMoney(moneys);
        } catch (NumSmallerThanZeroException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }

    public static int totalMoney(int[] arr)
            throws NumSmallerThanZeroException{
        int sum = 0;
        for (int money : arr) {
            if(money < 0){
                throw new NumSmallerThanZeroException("钱不能是负数", money);
            }
            sum = sum + money;
        }
        return sum;
    }
}
