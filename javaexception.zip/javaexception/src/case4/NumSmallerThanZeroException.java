package case4;

public class NumSmallerThanZeroException extends Exception{

    public int num;
    public NumSmallerThanZeroException(String message, int num) {
        super(message + ":" + num);
        this.num = num;
    }


}
