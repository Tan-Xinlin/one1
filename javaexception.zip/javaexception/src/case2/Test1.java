package case2;

public class Test1 {
    public static void main(String[] args) {
        int a = 0;
        int b = 2;
        int c;
        try {
            c = b/a;
        }catch (ArithmeticException e){
            //e.printStackTrace();//打开这一行注释结果是什么
            //e.getMessage();
            c = 0;
        }
        System.out.println(c);
    }
}
