package case2;

//异常处理方式2: throws关键字
public class Test4 {

    public static void main(String[] args){
        Test4.cal2();
    }

    //下面也可以用 throws Exception
    //直接用抛出Exception,
    //因为ArrayIndexOutOfBoundsException也是属于
    //Exception的一种
    public static void cal2() throws ArrayIndexOutOfBoundsException {
        int[] a = new int[2];
        for (int i = 0; i <= 2; i++) {
            a[i] = i;
        }
    }
}
