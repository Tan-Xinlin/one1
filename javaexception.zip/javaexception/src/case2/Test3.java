package case2;

import java.util.Scanner;

//知识点:1.两个catch的案例
//      2.或者直接使用父类Exception
public class Test3 {
    public static void main(String[] args) {
        try{
            int a = 0;
            int b = 2;
            int c = b / a;
            System.out.println(c);
            int[] d = new int[2];
            for (int i = 0; i <= 2; i++) {
                d[i] = i;
            }
        }catch (ArithmeticException e){
            e.printStackTrace();
            System.out.println("分母为0");
        }catch (ArrayIndexOutOfBoundsException e){
            e.printStackTrace();
            System.out.println("数组越界");
        }finally {
            System.out.println("都会执行");
        }

//        //直接使用父类Exception, 对两种子异常类进行合并
//        Scanner sc = new Scanner(System.in);
//        int aa = sc.nextInt();
//        try{
//            int b = 2;
//            int c = b / aa;
//            System.out.println(c);
//            int[] d = new int[2];
//            for (int i = 0; i <= 2; i++) {
//                d[i] = i;
//            }
//        }catch (Exception e){
//            e.printStackTrace();
//        }


    }



}
