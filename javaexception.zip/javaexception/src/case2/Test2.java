package case2;

import java.util.Scanner;

public class Test2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int b = 1;
        int a = scanner.nextInt();
        int c;
        try {
            c = b/a;
            b = 3;
        }catch (ArithmeticException e){
            c = 0;
        }finally {
            System.out.println("不管如何都会被运行");
        }
        System.out.println("b的值为:" + b);
        System.out.println("c的值为:" + c);
    }
}
